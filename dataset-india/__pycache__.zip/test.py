import pymongo
import os
import json
import requests
import csv

def fetch_filtered_messages_by_id(target_id, db_name="test", collection_name="qa_layer"):
    """
    Fetches messages from MongoDB based on a target ID.

    Args:
        target_id (str): The ID to filter messages.
        db_name (str): The name of the MongoDB database.
        collection_name (str): The name of the MongoDB collection.

    Returns:
        list: A list of dictionaries containing the filtered messages.
    """
    mongo_uri = os.environ.get("MONGO_URI")
    if not mongo_uri:
        raise EnvironmentError("MONGO_URI environment variable not set.")

    client = pymongo.MongoClient(mongo_uri)
    db = client[db_name]
    collection = db[collection_name]

    # Create the filter based on the target_id
    filter = {"uuid": target_id}

    # Fetch messages that match the filter
    messages = list(collection.find(filter))

    # Convert ObjectId to string for JSON serialization
    for message in messages:
        message["_id"] = str(message["_id"])

    client.close()
    return messages


def extract_testcases_from_responses(json_file="output.json"):
    """
    Extracts test cases from a JSON file containing API responses.

    Args:
        json_file (str): Path to the JSON file.

    Returns:
        list: A list of dictionaries, each representing a test case.
    """
    try:
        with open(json_file, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"Error: File not found: {json_file}")
        return []
    except json.JSONDecodeError:
        print(f"Error: Invalid JSON format in file: {json_file}")
        return []

    test_cases = []
    for item in data:
        uuid = item.get("uuid", "N/A")
        order_item_uuid = item.get("order_item_uuid", "N/A")
        user_query = item.get("user_query", "N/A")
        ai_response = item.get("ai_response", "N/A")

        test_case = {
            "UUID": uuid,
            "OrderItemUUID": order_item_uuid,
            "UserQuery": user_query,
            "AIResponse": ai_response,
        }
        test_cases.append(test_case)

    return test_cases


def send_context_and_save_response(context, output_filename="output.json"):
    """
    Sends context to an API endpoint and saves the response to a JSON file.

    Args:
        context (list): A list of dictionaries representing the context to send.
        output_filename (str): The name of the file to save the API response.

    Returns:
        str: The filename where the API response is saved.
    """
    api_endpoint = os.environ.get("API_ENDPOINT")
    if not api_endpoint:
        raise EnvironmentError("API_ENDPOINT environment variable not set.")

    headers = {"Content-Type": "application/json"}

    try:
        response = requests.post(api_endpoint, json=context, headers=headers)
        response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
        data = response.json()

        # Save the API response to a JSON file
        with open(output_filename, "w") as f:
            json.dump(data, f, indent=4)

        print(f"API response saved to {output_filename}")
        return output_filename

    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None


def extract_query_texts(json_file="testcases.json"):
    """
    Extracts user query texts from a JSON file.

    Args:
        json_file (str): Path to the JSON file containing test cases.

    Returns:
        list: A list of user query texts.
    """
    try:
        with open(json_file, "r") as f:
            test_cases = json.load(f)
    except FileNotFoundError:
        print(f"Error: File not found: {json_file}")
        return []
    except json.JSONDecodeError:
        print(f"Error: Invalid JSON format in file: {json_file}")
        return []

    queries = [test_case["UserQuery"] for test_case in test_cases]
    return queries


def run_api_sequence(query, order_item_uuid, num_iterations=1, csv_filename="query-sequence.csv"):
    """
    Runs a sequence of API calls with a given query and saves the results to a CSV file.

    Args:
        query (str): The user query to send to the API.
        order_item_uuid (str): The order item UUID associated with the query.
        num_iterations (int): The number of times to repeat the API call.
        csv_filename (str): The name of the CSV file to save the results.
    """
    api_endpoint = os.environ.get("API_ENDPOINT")
    if not api_endpoint:
        raise EnvironmentError("API_ENDPOINT environment variable not set.")

    # Check if the CSV file exists and write the header if it doesn't
    file_exists = os.path.isfile(csv_filename)
    with open(csv_filename, "a", newline="", encoding="utf-8") as csvfile:
        csv_writer = csv.writer(csvfile)

        if not file_exists:
            csv_writer.writerow(["UUID", "OrderItemUUID", "UserQuery", "AIResponse"])

        for _ in range(num_iterations):
            payload = {
                "uuid": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",  # Placeholder UUID
                "order_item_uuid": order_item_uuid,
                "user_query": query,
            }
            headers = {"Content-Type": "application/json"}

            try:
                response = requests.post(api_endpoint, json=payload, headers=headers)
                response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
                ai_response = response.json()

                # Write the data to the CSV file
                csv_writer.writerow(
                    [
                        payload["uuid"],
                        payload["order_item_uuid"],
                        payload["user_query"],
                        json.dumps(ai_response),  # Save the entire JSON response
                    ]
                )
                print(f"Query '{query}' processed and saved to {csv_filename}")

            except requests.exceptions.RequestException as e:
                print(f"Request failed for query '{query}': {e}")
                # Optionally, save the error to the CSV file
                csv_writer.writerow(
                    [
                        payload["uuid"],
                        payload["order_item_uuid"],
                        payload["user_query"],
                        f"Request Error: {str(e)}",
                    ]
                )


def orchestrate_pipeline(target_id):
    # Step 1: Fetch content from MongoDB
    content = fetch_filtered_messages_by_id(target_id=target_id)

    result = send_context_and_save_response(
        content,
    )

    # Step 2: Extract test cases from saved content
    testcases = extract_testcases_from_responses(result)

    # Save test cases to a JSON file
    testcases_filename = "testcases.json"
    with open(testcases_filename, "w") as f:
        json.dump(testcases, f, indent=4)

    # Step 3: Send test cases to API and save response
    queries = extract_query_texts(testcases_filename)
    for query in queries:
        run_api_sequence(query, "669ef7383ca0e006716c9c3802020600", num_iterations=1, csv_filename="query-sequence.csv")


if __name__ == "__main__":
    target_id = input("Enter the target ID: ")
    orchestrate_pipeline(
        target_id,
    )